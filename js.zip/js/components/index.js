import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import SignUpStep1 from './signup/step1'


if (document.getElementById('root')) {
    ReactDOM.render(<SignUpStep1 />, document.getElementById('root'));
}
