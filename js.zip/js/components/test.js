import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { Tabs, Tab, TabPanel, TabList } from 'react-web-tabs';
import { Progress } from 'react-sweet-progress';
import "react-sweet-progress/lib/style.css";
import Axios from 'axios';

export default class IkTestnogeens extends Component {



    render() {
        return (
            <div>
                <h2>ik test....</h2>
            </div>
        );
    }
}
